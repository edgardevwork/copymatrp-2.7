stock enter_buisnes(playerid, typee, b_id)
{
	new string[144];
	format(string, sizeof(string), "[%d]",b_id);
	SCM(playerid,0xFFFF,string);

	switch(buisness[b_id][type])
	{
		
		case BUISNES_AMMO:
		{
			SetPlayerPos(playerid, 9.9426,15.5443,1601.7458,359.7251);

			player_info[playerid][pSelectedBusinessID] = b_id;
			SetPlayerVirtualWorld(playerid, b_id);

			SetPVarInt(playerid, "buisnes_enter_type", BUISNES_AMMO);
			SetPVarInt(playerid, "buisnes_enter_id", b_id);	
		}
		case BUISNES_AMMO_2:
		{
			SetPlayerPos(playerid, 9.9426,15.5443,1601.7458,359.7251);

			player_info[playerid][pSelectedBusinessID] = b_id;
			SetPlayerVirtualWorld(playerid, b_id);

			SetPVarInt(playerid, "buisnes_enter_type", BUISNES_AMMO_2);
			SetPVarInt(playerid, "buisnes_enter_id", b_id);
		}
		case BUISNES_AUTOSALON_1:
		{
			SetPlayerPos(playerid, MAGAZINE_CAR_1_ENTER);
			SetPlayerVirtualWorld(playerid, 10);
			SetPlayerTime(playerid, 19, 0);
			SetPlayerInterior(playerid,1);
			
			SetPVarInt(playerid, "buisnes_enter_type", BUISNES_AUTOSALON_1);
			SetPVarInt(playerid, "buisnes_enter_id", b_id);

		}
		case BUISNES_AUTOSALON_2:
		{
			SetPlayerPos(playerid, MAGAZINE_CAR_2_ENTER);
			SetPlayerVirtualWorld(playerid, 10);		
			SetPlayerInterior(playerid,1);
			SetPlayerTime(playerid, 19, 0);
			
			SetPVarInt(playerid, "buisnes_enter_type", BUISNES_AUTOSALON_2);
			SetPVarInt(playerid, "buisnes_enter_id", b_id);

		}
		case BUISNES_AUTOSALON_3:
		{
			SetPlayerPos(playerid, MAGAZINE_CAR_3_ENTER);
			SetPlayerVirtualWorld(playerid, 10);		

			SetPlayerTime(playerid, 20, 0);
			SetPVarInt(playerid, "buisnes_enter_type", BUISNES_AUTOSALON_3);
			SetPVarInt(playerid, "buisnes_enter_id", b_id);

		}
		case BUISNES_PRODUCTION:
		{
			SetPlayerPos(playerid, BUISNES_PRODUCTION_ENTER);
			SetPlayerVirtualWorld(playerid, b_id);
			SetPlayerInterior(playerid,7);

			SetPVarInt(playerid, "buisnes_enter_type", BUISNES_PRODUCTION);
			SetPVarInt(playerid, "buisnes_enter_id", b_id);
		}
		case BUISNES_FASTFOOD:
		{
			SetPVarInt(playerid, "buisnes_enter_type", BUISNES_FASTFOOD);
			SetPVarInt(playerid, "buisnes_enter_id", b_id);	

			SetPlayerTime(playerid, 12, 0);

			SetPlayerPos(playerid, ENTER_FASTFOOD);
			SetPlayerVirtualWorld(playerid, b_id);
		}
		case BUISNES_CLUB:
		{
			SetPlayerPos(playerid, 141.3583,-1171.4988,1200.6801,0.9098);

			SetPVarInt(playerid, "buisnes_enter_type", BUISNES_CLUB);
			SetPVarInt(playerid, "buisnes_enter_id", b_id);	

			SetPlayerVirtualWorld(playerid, b_id);
		}
		case BUISNES_CLOTHES:
		{
			SetPVarInt(playerid, "buisnes_enter_type", BUISNES_CLOTHES);
			SetPVarInt(playerid, "buisnes_enter_id", b_id);				

			SetPlayerTime(playerid, 12, 0);

			SetPlayerPos(playerid, MAGAZING_CLOTHES_1_ENTER);
			SetPlayerVirtualWorld(playerid, b_id);	
		}
		case BUISNES_ACCESSORIES:
		{
			SetPVarInt(playerid, "buisnes_enter_type", BUISNES_ACCESSORIES);
			SetPVarInt(playerid, "buisnes_enter_id", b_id);
			SetPlayerInterior(playerid,8);

			SetPlayerPos(playerid, MAGAZIN_AKS_1_ENTER);
			SetPlayerVirtualWorld(playerid, b_id);			
		}
	}



	return true;
}
stock exit_buisnes(playerid, typee, b_id)
{

	switch(buisness[b_id][type])
	{
		case BUISNES_PRODUCTION:
		{
			SetPlayerPos(playerid, buisness[b_id][exit_x], buisness[b_id][exit_y], buisness[b_id][exit_z], 90.0);
			SetPlayerVirtualWorld(playerid, 0);
			SetPlayerInterior(playerid,0);

		}
		case BUISNES_BAR:
		{
			SetPlayerPos(playerid, buisness[b_id][exit_x], buisness[b_id][exit_y], buisness[b_id][exit_z], 90.0);
			SetPlayerVirtualWorld(playerid, 0);
			SetPlayerInterior(playerid,0);
			
		}
		case BUISNES_AMMO:
		{
			SetPlayerPos(playerid, buisness[b_id][exit_x], buisness[b_id][exit_y], buisness[b_id][exit_z], 90.0);
			SetPlayerVirtualWorld(playerid, 0);
			SetPlayerInterior(playerid,0);
			
		}
		case BUISNES_AMMO_2:
		{
			SetPlayerPos(playerid, buisness[b_id][exit_x], buisness[b_id][exit_y], buisness[b_id][exit_z], 90.0);
			SetPlayerVirtualWorld(playerid, 0);
			SetPlayerInterior(playerid,0);
			
		}
		case BUISNES_FASTFOOD:
		{
			SetPlayerPos(playerid, buisness[b_id][exit_x], buisness[b_id][exit_y], buisness[b_id][exit_z], 90.0);
			SetPlayerVirtualWorld(playerid, 0);
			SetPlayerInterior(playerid,0);
		

		}
		case BUISNES_CLUB:
		{
			SetPlayerPos(playerid, buisness[b_id][exit_x], buisness[b_id][exit_y], buisness[b_id][exit_z], 90.0);
			SetPlayerVirtualWorld(playerid, 0);
			SetPlayerInterior(playerid,0);
			
		}
		case BUISNES_AUTOSALON_1:
		{
			SetPlayerPos(playerid, buisness[b_id][exit_x], buisness[b_id][exit_y], buisness[b_id][exit_z], 90.0);
			SetPlayerVirtualWorld(playerid, 0);
			SetPlayerInterior(playerid,0);

		}
		case BUISNES_AUTOSALON_2:
		{

			SetPlayerPos(playerid, buisness[b_id][exit_x], buisness[b_id][exit_y], buisness[b_id][exit_z], 90.0);
			SetPlayerVirtualWorld(playerid, 0);
			SetPlayerInterior(playerid,0);
			
		}
		case BUISNES_AUTOSALON_3:
		{

			SetPlayerPos(playerid, buisness[b_id][exit_x], buisness[b_id][exit_y], buisness[b_id][exit_z], 90.0);
			SetPlayerVirtualWorld(playerid, 0);
			SetPlayerInterior(playerid,0);
			
		}
		case BUISNES_CLOTHES:
		{

			SetPlayerPos(playerid, buisness[b_id][exit_x], buisness[b_id][exit_y], buisness[b_id][exit_z], 90.0);
			SetPlayerVirtualWorld(playerid, 0);
			SetPlayerInterior(playerid,0);
			
		}
		case BUISNES_ACCESSORIES:
		{

			SetPlayerPos(playerid, buisness[b_id][exit_x], buisness[b_id][exit_y], buisness[b_id][exit_z], 90.0);
			SetPlayerVirtualWorld(playerid, 0);
			SetPlayerInterior(playerid,0);
		}

	}

	clear_pvar_buisnes(playerid);

	return true;
}
stock clear_pvar_buisnes(playerid)
{
	DeletePVar(playerid, "buisnes_enter_type");
	DeletePVar(playerid, "buisnes_enter_id");
	return true;
}