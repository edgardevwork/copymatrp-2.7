new String320[320];

static const get_buisnes_autosalon_n[][] =
{	
	"�����������",
    "���� �������",
    "���� ����",
    "���������",
    "��������"
};

public load_buisnes_all()
{
	new buisnes_names[124];
	new Cache: result;
	result= mysql_query(dbHandle, "SELECT * FROM `buisness` ORDER BY `buisnes_id`", true);
	new rows;
	cache_get_row_count(rows);
 	for(new i; i < rows; i++)
	{
		cache_get_value_name_int(i, "buisnes_id",buisness[i][id]);
		cache_get_value_name_int(i, "buisnes_owner_id", buisness[i][owned]);
		cache_get_value_name_int(i, "buisnes_name", buisness[i][name]);
		cache_get_value_name(i, "buisness_owner_name", buisness[i][owner],124);
		cache_get_value_name_int(i, "buisnes_type", buisness[i][type]);
		cache_get_value_name_int(i, "buisnes_price", buisness[i][price]);
		cache_get_value_name_int(i, "buisnes_lock", buisness[i][lock]);
		cache_get_value_name_int(i, "buisnes_nalog", buisness[i][takings]);
		cache_get_value_name_int(i, "buisnes_day", buisness[i][days]);
		cache_get_value_name_int(i, "buisnes_bank", buisness[i][bank]);
		cache_get_value_name_int(i, "buisnes_enterprice", buisness[i][enterprice]);
		cache_get_value_name_float(i, "buisnes_enter_x", buisness[i][enter_x]);
		cache_get_value_name_float(i, "buisnes_enter_y", buisness[i][enter_y]);
		cache_get_value_name_float(i, "buisnes_enter_z", buisness[i][enter_z]);
		cache_get_value_name_float(i, "buisnes_exit_x", buisness[i][exit_x]);
		cache_get_value_name_float(i, "buisnes_exit_y", buisness[i][exit_y]);
		cache_get_value_name_float(i, "buisnes_exit_z", buisness[i][exit_z]);
		cache_get_value_name_int(i, "buisnes_upgrade_1", buisness[i][upgrade_1]);
		cache_get_value_name_int(i, "buisnes_upgrade_2", buisness[i][upgrade_2]);
		cache_get_value_name_int(i, "buisnes_upgrade_3", buisness[i][upgrade_3]);
		cache_get_value_name_int(i, "buisnes_upgrade_4", buisness[i][upgrade_4]);
		cache_get_value_name_int(i, "buisnes_upgrade_5", buisness[i][upgrade_5]);
		cache_get_value_name_int(i, "buisnes_upgrade_6", buisness[i][upgrade_6]);
		cache_get_value_name_int(i, "buisnes_finka_ogran", buisness[i][finka_ogran]);
		cache_get_value_name_int(i, "buisnes_finka_day", buisness[i][finka_day]);
		cache_get_value_name_int(i, "buisnes_count_prod", buisness[i][count_prod]);
		cache_get_value_name_int(i, "buisnes_status_sell", buisness[i][status_sell]);
		cache_get_value_name_int(i, "buisnes_sell_day_payday", buisness[i][sell_day_payday]);
		cache_get_value_name_int(i, "buisnes_price_day_rent", buisness[i][price_day_rent]);
		cache_get_value_name_int(i, "buisnes_mafia", buisness[i][mafia]);
		buisness[i][b_pickup] = CreatePickup(13702, 23, buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 0,PICKUP_ACTION_TYPE_BIZ_ENTER,i);

		new b_owner[124];
		cache_get_value_name(i, "buisness_owner_name",b_owner,124);
		
		if(buisness[i][type] == BUISNES_CLOTHES)
		{

			CreateDynamic3DTextLabel("����� �� ��������",-1, \
			MAGAZING_CLOTHES_1_EXIT, 2.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 20, -1);	
			
			buisnes_names =get_buisnes_clothes_n(i);
			//format(buisnes_names, 124, "%s", get_buisnes_clothes_n(i));

			if(buisness[i][owned] == -1)
			{
				b_owner = "�����������";
			}

			format(String320, sizeof(String320), "\
				"cWH"������� ������ "cBLUE"�%d\n\n\
				"cBLUE"��������: \
				"cWH"%s\n\
				"cBLUE"��������: \
				"cWH"%s\n", 
				i+1, 
				buisnes_names, 
				b_owner);

			buisness[i][b_pickup_text] = CreateDynamic3DTextLabel(String320, -1, buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 5.0);

			

			//create_dynamic_area(MAGAZING_CLOTHES_1_EXIT, i, i, B_EXIT);
			if(buisness[i][owned] == -1)
			{
				buisness[i][mapicon] = CreateDynamicMapIcon(buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 45, COLOR_WHITE, 0, -1, -1, 100.0);
			}
			else
			{
				buisness[i][mapicon] = CreateDynamicMapIcon(buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 45, COLOR_RED, 0, -1, -1, 100.0);
			}
		}
		
		if(buisness[i][type] == BUISNES_ACCESSORIES)
		{

			CreateDynamic3DTextLabel(""cWH"����� �� ��������",-1, \
			MAGAZIN_AKS_1_EXIT, 2.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 20, -1);	


			new buisnes_names[24];
			new	b_owner[24];

			format(buisnes_names, 24, "%s", get_buisnes_aks_n(i));

			if(buisness[i][owned] == -1)
			{
				b_owner = "�����������";
			}

			format(String320, sizeof(String320), "\
				"cWH"������� ����������� "cBLUE"�%d\n\n\
				"cBLUE"��������: \
				"cWH"%s\n\
				"cBLUE"��������: \
				"cWH"%s\n", i+1, buisnes_names, b_owner);

			buisness[i][b_pickup_text] = CreateDynamic3DTextLabel(String320, -1, buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 5.0);

			

			if(buisness[i][owned] == -1)
			{
				buisness[i][mapicon] = CreateDynamicMapIcon(buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 39, COLOR_WHITE, 0, -1, -1, 100.0);
			}
			else
			{
				buisness[i][mapicon] = CreateDynamicMapIcon(buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 39, COLOR_RED, 0, -1, -1, 100.0);
			}
		}
		
		
		if(buisness[i][type] == BUISNES_AUTOSALON_1)
		{

			CreateDynamic3DTextLabel(""cWH"����� �� ����������",-1, \
			MAGAZINE_CAR_1_EXIT, 2.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 0, -1);	
			printf("%s - %f,%f,%f",get_buisnes_autosalon_n[buisness[i][name]],buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z]);
			autosalonns[1][x]=buisness[i][enter_x];
			autosalonns[1][y]=buisness[i][enter_y];
			autosalonns[1][z]=buisness[i][enter_z];
			new buisnes_names[24];
			new	b_owner[24];

			format(buisnes_names, 24, "%s", get_buisnes_autosalon_n[buisness[i][name]]);

			if(buisness[i][owned] == -1)
			{
				b_owner = "�����������";
			}

			format(String320, sizeof(String320), "\
				"cWH"��������� "cBLUE"�%d\n\n\
				"cBLUE"��������: \
				"cWH"%s\n\
				"cBLUE"��������: \
				"cWH"%s\n", 
				i+1, 
				buisnes_names, 
				b_owner);

			buisness[i][b_pickup_text] = CreateDynamic3DTextLabel(String320, -1, buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 5.0);


			autosalon_count_rent_car[0] = MAX_RENT_CAR_AUTOSALON_1;

			

			if(buisness[i][owned] == -1)
			{
				buisness[i][mapicon] = CreateDynamicMapIcon(buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 55, COLOR_WHITE, 0, -1, -1, 100.0);
			}
			else
			{
				buisness[i][mapicon] = CreateDynamicMapIcon(buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 55, COLOR_RED, 0, -1, -1, 100.0);
			}
		}

		if(buisness[i][type] == BUISNES_AUTOSALON_2)
		{

			CreateDynamic3DTextLabel(""cWH"����� �� ����������",-1, \
			MAGAZINE_CAR_2_EXIT, 2.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 0, -1);	

			printf("%s - %f,%f,%f",get_buisnes_autosalon_n[buisness[i][name]],buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z]);
			new buisnes_names[24];
			new	b_owner[24];
			autosalonns[2][x]=buisness[i][enter_x];
			autosalonns[2][y]=buisness[i][enter_y];
			autosalonns[2][z]=buisness[i][enter_z];
			format(buisnes_names, 24, "%s", get_buisnes_autosalon_n[buisness[i][name]]);

			if(buisness[i][owned] == -1)
			{
				b_owner = "�����������";
			}

			format(String320, sizeof(String320), "\
				"cWH"��������� "cBLUE"�%d\n\n\
				"cBLUE"��������: \
				"cWH"%s\n\
				"cBLUE"��������: \
				"cWH"%s\n", i+1, buisnes_names, b_owner);

			buisness[i][b_pickup_text] = CreateDynamic3DTextLabel(String320, -1, buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 5.0);

			autosalon_count_rent_car[1] = MAX_RENT_CAR_AUTOSALON_2;

			


			if(buisness[i][owned] == -1)
			{
				buisness[i][mapicon] = CreateDynamicMapIcon(buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 55, COLOR_WHITE, 0, -1, -1, 100.0);
			}
			else
			{
				buisness[i][mapicon] = CreateDynamicMapIcon(buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 55, COLOR_RED, 0, -1, -1, 100.0);
			}
		}

		if(buisness[i][type] == BUISNES_AUTOSALON_3)
		{

			CreateDynamic3DTextLabel(""cWH"����� �� ����������",-1, \
			MAGAZINE_CAR_3_EXIT, 2.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 0, -1);	

			printf("%s - %f,%f,%f",get_buisnes_autosalon_n[buisness[i][name]],buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z]);
			new buisnes_names[24];
			new	b_owner[24];
			autosalonns[0][x]=buisness[i][enter_x];
			autosalonns[0][y]=buisness[i][enter_y];
			autosalonns[0][z]=buisness[i][enter_z];
			format(buisnes_names, 24, "%s", get_buisnes_autosalon_n[buisness[i][name]]);

			if(buisness[i][owned] == -1)
			{
				b_owner = "�����������";
			}

			format(String320, sizeof(String320), "\
				"cWH"��������� "cBLUE"�%d\n\n\
				"cBLUE"��������: \
				"cWH"%s\n\
				"cBLUE"��������: \
				"cWH"%s\n", 
				i+1, 
				buisnes_names, 
				b_owner);

			buisness[i][b_pickup_text] = CreateDynamic3DTextLabel(String320, -1, buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 5.0);

			autosalon_count_rent_car[2] = MAX_RENT_CAR_AUTOSALON_3;

			


			if(buisness[i][owned] == -1)
			{
				buisness[i][mapicon] = CreateDynamicMapIcon(buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 55, COLOR_WHITE, 0, -1, -1, 100.0);
			}
			else
			{
				buisness[i][mapicon] = CreateDynamicMapIcon(buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 55, COLOR_RED, 0, -1, -1, 100.0);
			}
		}


		if(buisness[i][type] == BUISNES_PRODUCTION)
		{

			CreateDynamic3DTextLabel(""cWH"����� �� ��������",-1, \
			BUISNES_PRODUCTION_EXIT, 2.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 0, -1);	

			new buisnes_names[24];
			new	b_owner[24];

			format(buisnes_names, 24, "%s", get_buisnes_univermag_n(i));

			if(buisness[i][owned] == -1)
			{
				b_owner = "�����������";
			}

			format(String320, sizeof(String320), "\
				"cWH"����������� ������� "cBLUE"�%d\n\n\
				"cBLUE"��������: \
				"cWH"%s\n\
				"cBLUE"��������: \
				"cWH"%s\n", i+1, buisnes_names, b_owner);

			buisness[i][b_pickup_text] = CreateDynamic3DTextLabel(String320, -1, buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 5.0);


			

			if(buisness[i][owned] == -1)
			{
				buisness[i][mapicon] = CreateDynamicMapIcon(buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 52, COLOR_WHITE, 0, -1, -1, 100.0);
			}
			else
			{
				buisness[i][mapicon] = CreateDynamicMapIcon(buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 52, COLOR_RED, 0, -1, -1, 100.0);
			}
		}

		if(buisness[i][type] == BUISNES_AMMO)
		{

			CreateDynamic3DTextLabel(""cWH"����� �� ��������",-1, \
			9.9908,14.8014,1601.7458, 2.0, INVALID_PLAYER_ID, INVALID_VEHICLE_ID, 0, -1);	

			new buisnes_names[24];
			new	b_owner[24];

			format(buisnes_names, 24, "%s", get_buisnes_ammo_n(i));

			if(buisness[i][owned] == -1)
			{
				b_owner = "�����������";
			}

			format(String320, sizeof(String320), "\
				"cWH"������� ������ "cBLUE"�%d\n\n\
				"cBLUE"��������: \
				"cWH"%s\n\
				"cBLUE"��������: \
				"cWH"%s\n", i+1, buisnes_names, b_owner);



			buisness[i][b_pickup_text] = CreateDynamic3DTextLabel(String320, -1, buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 5.0);



			

			if(buisness[i][owned] == -1)
			{
				buisness[i][mapicon] = CreateDynamicMapIcon(buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 6, COLOR_WHITE, 0, -1, -1, 100.0);
			}
			else
			{
				buisness[i][mapicon] = CreateDynamicMapIcon(buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 6, COLOR_RED, 0, -1, -1, 100.0);
			}
		}
		if(buisness[i][type] == BUISNES_AMMO_2)
		{
			new buisnes_names[24];
			new	b_owner[24];

			format(buisnes_names, 24, "%s", get_buisnes_ammo_n(i));

			if(buisness[i][owned] == -1)
			{
				b_owner = "�����������";
			}

			format(String320, sizeof(String320), "\
				"cWH"������� ������ "cBLUE"�%d\n\n\
				"cBLUE"��������: \
				"cWH"%s\n\
				"cBLUE"��������: \
				"cWH"%s\n", i+1, buisnes_names, b_owner);

			buisness[i][b_pickup_text] = CreateDynamic3DTextLabel(String320, -1, buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 5.0);
			

			if(buisness[i][owned] == -1)
			{
				buisness[i][mapicon] = CreateDynamicMapIcon(buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 6, COLOR_WHITE, 0, -1, -1, 100.0);
			}
			else
			{
				buisness[i][mapicon] = CreateDynamicMapIcon(buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 6, COLOR_RED, 0, -1, -1, 100.0);
			}
		}/*
		if(buisness[i][type] == BUISNES_RESTORAN)
		{

			buisness[i][b_pickup] = CreateDynamicPickup(13702, 23, POSITION_RESTORAN, -1, -1, -1, 10.0);

			new buisnes_names[24];
			new	b_owner[24];

			format(buisnes_names, 24, "%s", get_buisnes_restoran_n(i));

			if(buisness[i][owned] == -1)
			{
				b_owner = "�����������";
			}

			format(String320, sizeof(String320), "\
				"cWH"�������� "cBLUE"�%d\n\n\
				"cBLUE"��������: \
				"cWH"%s\n\
				"cBLUE"��������: \
				"cWH"%s", i+1, buisnes_names, b_owner);

			buisness[i][b_pickup] = CreateDynamic3DTextLabel(String320, -1, buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 5.0);



			if(buisness[i][owned] == -1)
			{
				buisness[i][mapicon] = CreateDynamicMapIcon(buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 50, COLOR_WHITE, 0, -1, -1, 100.0);
			}
			else
			{
				buisness[i][mapicon] = CreateDynamicMapIcon(buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 50, COLOR_RED, 0, -1, -1, 100.0);
			}
			create_dynamic_area(POSITION_RESTORAN, i, i, B_EXIT);
		}

		if(buisness[i][type] == BUISNES_FASTFOOD)
		{

			buisness[i][b_pickup] = CreateDynamicPickup(13702, 23, POSITION_FASTFOOD, -1, -1, -1, 10.0);

			new buisnes_names[24];
			new	b_owner[24];

			format(buisnes_names, 24, "%s", get_buisnes_fastfood_n(i));

			if(buisness[i][owned] == -1)
			{
				b_owner = "�����������";
			}

			format(String320, sizeof(String320), "\
				"cWH"���������� "cBLUE"�%d\n\n\
				"cBLUE"��������: \
				"cWH"%s\n\
				"cBLUE"��������: \
				"cWH"%s\n", i+1, buisnes_names, b_owner);

			buisness[i][b_pickup] = CreateDynamic3DTextLabel(String320, -1, buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 5.0);


			if(buisness[i][owned] == -1)
			{
				buisness[i][mapicon] = CreateDynamicMapIcon(buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 10, COLOR_WHITE, 0, -1, -1, 100.0);
			}
			else
			{
				buisness[i][mapicon] = CreateDynamicMapIcon(buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 10, COLOR_RED, 0, -1, -1, 100.0);
			}

			create_dynamic_area(POSITION_FASTFOOD, i, i, B_EXIT);
		}

		if(buisness[i][type] == BUISNES_CLUB)
		{
			new buisnes_names[24];
			new	b_owner[24];

			buisness[i][b_pickup] = CreateDynamicPickup(13702, 23, 141.3090,-1172.5457,1200.6801, -1, -1, -1, 10.0);


			format(buisnes_names, 24, "%s", get_buisnes_club_n(i));

			if(buisness[i][owned] == -1)
			{
				b_owner = "�����������";
			}

			format(String320, sizeof(String320), "\
				"cWH"������ ���� "cBLUE"�%d\n\n\
				"cBLUE"��������: \
				"cWH"%s\n\
				"cBLUE"��������: \
				"cWH"%s\n", i+1, buisnes_names, b_owner); 

			buisness[i][b_pickup] = CreateDynamic3DTextLabel(String320, -1, buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 5.0);

			arClubBar = create_circle_pickup(158.9573,-1152.2617,1201.7816, TRIGGER_LBLUE);	
			create_dynamic_area(141.3090,-1172.5457,1200.6801, i, i, B_EXIT);

			if(buisness[i][owned] == -1)
			{
				buisness[i][mapicon] = CreateDynamicMapIcon(buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 48, COLOR_WHITE, 0, -1, -1, 100.0);
			}
			else
			{
				buisness[i][mapicon] = CreateDynamicMapIcon(buisness[i][enter_x], buisness[i][enter_y], buisness[i][enter_z], 48, COLOR_RED, 0, -1, -1, 100.0);
			}
		}*/

  		all_buisness++;
	}
	cache_delete(result);
	load_buis_exit_pickup();
	printf("[�������]: <%i �� %i>." ,rows, all_buisness);

	return true;
}

stock get_buisnes_clothes_n(h)
{
	new namee[40];
	new	class = buisness[h][name];

	switch(class)
	{
		case 1: 
			namee = "Waikiki";
		case 2: 
			namee = "NewYorker";
		case 3: 
			namee = "Bershka";
		default: 
			namee = "�����������";
	}
	return namee;
}
stock get_buisnes_aks_n(h)
{
	new 
		namee[40],
		class = buisness[h][name];

	switch(class)
	{
		case 1: namee = "MontanaShop";
		case 2: namee = "Gucci";
		case 3: namee = "ZaraShop";
		case 4: namee = "Prado";
		default: namee = "�����������";
	}
	return namee;
}
stock get_buisnes_univermag_n(h)
{
	new 
		namee[40],
		class = buisness[h][name];

	switch(class)
	{
		case 1: namee = "��������� ��������";
		case 2: namee = "��������� �������";
		case 3: namee = "��������� ����������";
		case 4: namee = "��������� ��������";
		default: namee = "�����������";
	}
	return namee;
}

stock get_buisnes_bar_n(h)
{
	new 
		namee[40],
		class = buisness[h][name];

	switch(class)
	{
		case 1: namee = "��� '������� �������'";
		case 2: namee = "��� '������ �����'";
		default: namee = "�����������";
	}
	return namee;
}

stock get_buisnes_ammo_n(h)
{
	new 
		namee[40],
		class = buisness[h][name];

	switch(class)
	{
		case 1: namee = "������� ������ '�������'";
		case 2: namee = "������� ������ '�������'";
		default: namee = "�����������";
	}
	return namee;
}

stock get_buisnes_restoran_n(h)
{
	new 
		namee[40],
		class = buisness[h][name];

	switch(class)
	{
		case 1: namee = "�������� '���������'";
		case 2: namee = "�������� '���������'";
		default: namee = "�����������";
	}
	return namee;
}

stock get_buisnes_fastfood_n(h)
{
	new 
		namee[40],
		class = buisness[h][name];

	switch(class)
	{
		case 1: namee = "���������� 'Burgerking'";
		case 2: namee = "���������� 'KFC'";
		default: namee = "�����������";
	}
	return namee;
}

stock get_buisnes_club_n(h)
{
	new 
		namee[40],
		class = buisness[h][name];

	switch(class)
	{
		case 1: namee = "���� '������� �������'";
		case 2: namee = "���� '������ �����'";
		default: namee = "�����������";
	}
	return namee;
}

stock load_buis_exit_pickup(){
	CreatePickup(1318,23,BUISNES_PRODUCTION_EXIT,-1,PICKUP_ACTION_TYPE_BIZ_EXIT);
	CreatePickup(1318,23,MAGAZINE_CAR_1_EXIT,-1,PICKUP_ACTION_TYPE_BIZ_EXIT);
	CreatePickup(1318,23,MAGAZINE_CAR_2_EXIT,-1,PICKUP_ACTION_TYPE_BIZ_EXIT);
	CreatePickup(1318,23,MAGAZINE_CAR_3_EXIT,-1,PICKUP_ACTION_TYPE_BIZ_EXIT);
	CreatePickup(1318,23,MAGAZING_CLOTHES_1_EXIT,-1,PICKUP_ACTION_TYPE_BIZ_EXIT);
	CreatePickup(1318,23,MAGAZIN_AKS_1_EXIT,-1,PICKUP_ACTION_TYPE_BIZ_EXIT);
}