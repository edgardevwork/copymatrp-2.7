forward LoadFraction(id1);
public LoadFraction(id1)
{
	new rows;
	cache_get_row_count(rows);
	if (rows) {
	    cache_get_value_name_int(0,"id",fractions[id1][id]);
	    cache_get_value_name_int(0,"skin",fractions[id1][skin]);
	    cache_get_value_name(0,"name",fractions[id1][name],40);
	    cache_get_value_name_int(0,"x",fractions[id1][x]);
	    cache_get_value_name_int(0,"y",fractions[id1][y]);
	    cache_get_value_name_int(0,"z",fractions[id1][z]);
	    cache_get_value_name_int(0,"a",fractions[id1][a]);
	    cache_get_value_name_int(0,"bank",fractions[id1][bank]);
	    cache_get_value_name_int(0,"vw",fractions[id1][vw]);
	    cache_get_value_name_int(0,"type",fractions[id1][type]);
	    
	    //fractions[id1][ranks][10] = "Авторитет";
	    //fractions[id1][ranks][10] = "Президент";
	}
}
