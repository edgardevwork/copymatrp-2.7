forward PlayerLogin(playerid);
public PlayerLogin(playerid){
	new rows;
	cache_get_row_count(rows);
	if (rows) {
	    cache_get_value_name_int(0,"id",player_info[playerid][pId]);
	    cache_get_value_name(0,"name",player_info[playerid][pName], MAX_PLAYER_NAME);
	    cache_get_value_name_int(0,"skin",player_info[playerid][pSkin]);
	    cache_get_value_name_int(0,"cash",player_info[playerid][pCash]);
	    cache_get_value_name_int(0,"sex",player_info[playerid][pSex]);
	    cache_get_value_name_int(0,"admin",player_info[playerid][pAdmin]);
		//
		cache_get_value_name_int(0,"helper",player_info[playerid][pHelper]);
		cache_get_value_name_int(0,"adminpass",player_info[playerid][pAdminPass]);
		//
	    cache_get_value_name_int(0,"bank",player_info[playerid][pBank]);
	    cache_get_value_name_int(0,"fraction",player_info[playerid][pFraction]);
	    cache_get_value_name_int(0,"house",player_info[playerid][pHouse]);
	    cache_get_value_name_int(0,"business",player_info[playerid][pBusiness]);
	    cache_get_value_name_int(0,"donate",player_info[playerid][pDonate]);
	    cache_get_value_name_int(0,"number",player_info[playerid][pNumber]);
		cache_get_value_name_int(0,"numcash",player_info[playerid][pNumberCash]);
	    cache_get_value_name_int(0,"rank",player_info[playerid][pRank]);
	    cache_get_value_name_int(0,"lvl",player_info[playerid][pLvl]);
	    cache_get_value_name_int(0,"exp",player_info[playerid][pExp]);
	    cache_get_value_name_int(0,"min",player_info[playerid][pMin]);
	    cache_get_value_name_int(0,"needexp",player_info[playerid][pNeedExp]);
		cache_get_value_name_int(0,"aid_kit",player_info[playerid][pAid]);
		cache_get_value_name_int(0,"health",player_info[playerid][pHealth]);
		cache_get_value_name_int(0,"food",player_info[playerid][pFood]);
		cache_get_value_name_int(0,"masks",player_info[playerid][pMasks]);
	    
     	SetSpawnInfo(playerid,0,player_info[playerid][pSkin],1866,2268,15,237,0,0,0,0,0,0);
     	SpawnPlayer(playerid);
	}
	return 1;
}
stock SendMessageToAdmins(message[], color, a_level = 1)
{
	if(a_level < 1)
		a_level = 1;

	new count;
	foreach(new playerid : Player)
	{
		if(!IsPlayerLogged(playerid)) continue;
		if(GetPlayerAdminEx(playerid) < a_level) continue;

		SendClientMessage(playerid, color, message);
		count ++;
	}
	return count;
}
stock GetPlayerIDBySqlID(sql_id)
{
	new playerid = INVALID_PLAYER_ID;

	foreach(new idx : Player)
	{
		if(!IsPlayerLogged(idx)) continue;
		if(GetPlayerAccountID(idx) != sql_id) continue;

		playerid = idx;
		break;
	}
	return playerid;
}

stock GetPlayerID(name[], playerid=INVALID_PLAYER_ID)
{
	sscanf(name, "u", playerid);

	return playerid;
}

stock GetPlayerSqlIDByName(name[])
{
	new sql_id,
		query[80],
		Cache: result;

	mysql_format(mysql, query, sizeof query, "SELECT id FROM `accounts` WHERE name = '%s' LIMIT 1", name);
	result = mysql_query(mysql, query, true);

	sql_id = cache_num_rows() ? cache_get_row_int(0, 0) : -1;

	cache_delete(result);

	return sql_id;
}

stock GetPlayerNameBySqlID(sql_id)
{
	new name[21] = "none",
		query[80],
		Cache: result;

	mysql_format(mysql, query, sizeof query, "SELECT name FROM `accounts` WHERE id = '%e' LIMIT 1", sql_id);
	result = mysql_query(mysql, query, true);

	if(cache_num_rows())
		cache_get_row(0, 0, name);

	cache_delete(result);

	return name;
}
stock IsPlayerHaveWeapon(playerid, weaponid)
{
	new weapon, ammo;
	new bool: is_have = false;

	for(new idx; idx <= 12; idx ++)
	{
		GetPlayerWeaponData(playerid, idx, weapon, ammo);
		if(weapon != weaponid) continue;

		is_have = true;
		break;
	}
	return is_have;
}
stock ShowPlayerBuyRepairCarDialog(playerid, stationid)
{
	if(stationid != -1)
	{
		SetPVarInt(playerid, "buy_jerrican_in_fuelst", stationid);

		new fmt_str[70];
		format
		(
			fmt_str, sizeof fmt_str,
			"{FFFFFF}���. �������� ����� 100.000$\n"\
			"�� ������ ������ ��?"
		);
		Dialog(playerid, DIALOG_FUEL_STATION_BUY_REPAIR, DIALOG_STYLE_MSGBOX, "���", fmt_str, "��", "���");
	}
	else SendClientMessage(playerid, 0xCECECEFF, "��� �������� ����� ������ �� ����� ���");
}
stock GetPlayerSpeed(playerid)
{
	new Float: x, Float: y, Float: z;
	if(IsPlayerInAnyVehicle(playerid))
	{
		GetVehicleVelocity(GetPlayerVehicleID(playerid), x, y, z);
	}
	else GetPlayerVelocity(playerid, x, y, z);

	return floatround(floatsqroot(x*x+y*y+z*z)*100);
}
stock IsPlayerDriver(playerid) // ����� �� ����� �� ����� ��
{
	return (IsPlayerInAnyVehicle(playerid) && GetPlayerState(playerid) == PLAYER_STATE_DRIVER);
}

stock IsPlayerPassenger(playerid) // ����� �� ����� ��� ��������
{
	return (IsPlayerInAnyVehicle(playerid) && GetPlayerState(playerid) == PLAYER_STATE_PASSENGER);
}