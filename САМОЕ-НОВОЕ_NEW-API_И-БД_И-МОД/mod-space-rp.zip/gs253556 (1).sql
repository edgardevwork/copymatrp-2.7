-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Час створення: Квт 03 2024 р., 10:20
-- Версія сервера: 10.3.31-MariaDB-0+deb10u1
-- Версія PHP: 7.3.31-1~deb10u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База даних: `gs253556`
--

-- --------------------------------------------------------

--
-- Структура таблиці `accounts`
--

CREATE TABLE `accounts` (
  `id` int(8) NOT NULL,
  `name` varchar(24) NOT NULL,
  `skin` int(255) NOT NULL DEFAULT 116,
  `cash` int(10) NOT NULL DEFAULT 1000,
  `promo` varchar(10) NOT NULL,
  `sex` int(1) NOT NULL,
  `admin` int(1) NOT NULL,
  `bank` int(9) NOT NULL,
  `fraction` int(2) NOT NULL,
  `house` int(3) NOT NULL,
  `business` int(3) NOT NULL,
  `donate` int(9) NOT NULL DEFAULT 0,
  `number` int(6) NOT NULL,
  `numcash` int(11) DEFAULT 0,
  `rank` int(2) NOT NULL,
  `lvl` int(4) NOT NULL DEFAULT 1,
  `exp` int(4) NOT NULL DEFAULT 0,
  `min` int(2) NOT NULL DEFAULT 0,
  `needexp` int(10) NOT NULL DEFAULT 4,
  `aid_kit` int(11) NOT NULL DEFAULT 0,
  `masks` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп даних таблиці `accounts`
--

INSERT INTO `accounts` (`id`, `name`, `skin`, `cash`, `promo`, `sex`, `admin`, `bank`, `fraction`, `house`, `business`, `donate`, `number`, `numcash`, `rank`, `lvl`, `exp`, `min`, `needexp`, `aid_kit`, `masks`) VALUES
(12, 'Edgar_Tg', 98, 1000, '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 2, 4, 0, 0),
(13, 'Admin_Dev', 40, 1000, '', 0, 1000, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 28, 4, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблиці `buisness`
--

CREATE TABLE `buisness` (
  `buisnes_id` int(11) NOT NULL,
  `buisnes_owner_id` int(11) NOT NULL DEFAULT -1,
  `buisness_owner_name` varchar(124) NOT NULL,
  `buisnes_name` varchar(255) DEFAULT NULL,
  `buisnes_type` int(11) DEFAULT NULL,
  `buisnes_price` int(11) DEFAULT NULL,
  `buisnes_lock` int(11) DEFAULT NULL,
  `buisnes_takings` int(11) DEFAULT NULL,
  `buisnes_days` int(11) DEFAULT NULL,
  `buisnes_bank` int(11) DEFAULT NULL,
  `buisnes_enterprice` int(11) DEFAULT NULL,
  `buisnes_enter_x` float DEFAULT NULL,
  `buisnes_enter_y` float DEFAULT NULL,
  `buisnes_enter_z` float DEFAULT NULL,
  `buisnes_exit_x` float DEFAULT NULL,
  `buisnes_exit_y` float DEFAULT NULL,
  `buisnes_exit_z` float DEFAULT NULL,
  `buisnes_upgrade_1` int(11) DEFAULT NULL,
  `buisnes_upgrade_2` int(11) DEFAULT NULL,
  `buisnes_upgrade_3` int(11) DEFAULT NULL,
  `buisnes_upgrade_4` int(11) DEFAULT NULL,
  `buisnes_upgrade_5` int(11) DEFAULT NULL,
  `buisnes_upgrade_6` int(11) DEFAULT NULL,
  `buisnes_finka_ogran` int(11) DEFAULT NULL,
  `buisnes_finka_day` int(11) DEFAULT NULL,
  `buisnes_count_prod` int(11) DEFAULT NULL,
  `buisnes_status_sell` int(11) DEFAULT NULL,
  `buisnes_sell_day_payday` int(11) DEFAULT NULL,
  `buisnes_price_day_rent` int(11) DEFAULT NULL,
  `buisnes_nalog` int(11) NOT NULL,
  `buisnes_xuy_3naet` int(11) NOT NULL,
  `buisnes_mafia` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп даних таблиці `buisness`
--

INSERT INTO `buisness` (`buisnes_id`, `buisnes_owner_id`, `buisness_owner_name`, `buisnes_name`, `buisnes_type`, `buisnes_price`, `buisnes_lock`, `buisnes_takings`, `buisnes_days`, `buisnes_bank`, `buisnes_enterprice`, `buisnes_enter_x`, `buisnes_enter_y`, `buisnes_enter_z`, `buisnes_exit_x`, `buisnes_exit_y`, `buisnes_exit_z`, `buisnes_upgrade_1`, `buisnes_upgrade_2`, `buisnes_upgrade_3`, `buisnes_upgrade_4`, `buisnes_upgrade_5`, `buisnes_upgrade_6`, `buisnes_finka_ogran`, `buisnes_finka_day`, `buisnes_count_prod`, `buisnes_status_sell`, `buisnes_sell_day_payday`, `buisnes_price_day_rent`, `buisnes_nalog`, `buisnes_xuy_3naet`, `buisnes_mafia`) VALUES
(1, -1, '', '0', 5, 2100000, 1, NULL, 28, 0, 100, 155.283, 571.941, 12.2188, 155.283, 571.941, 12.2188, 0, 0, 0, 0, 0, 0, 9999999, 0, 3609, 0, -1, 0, 10000, 0, 14),
(2, -1, '', '0', 2, 1950000, 1, NULL, 3, 0, 100, -288.882, 956.273, 12.6391, -288.882, 956.273, 12.6391, 0, 0, 0, 0, 0, 0, 9999999, 0, 4950, 0, -1, 0, 10000, 0, 15),
(3, -1, '', '0', 6, 1300000, 1, NULL, 4, 4360, 100, -5.2316, 911.606, 12.002, -5.2316, 911.606, 12.002, 0, 0, 0, 0, 0, 0, 9999999, 0, -255, 0, -1, 0, 10000, 0, 13),
(4, -1, '', '0', 4, 1870000, 1, NULL, 3, 0, 100, 252.94, 460.923, 12.0625, 252.94, 460.923, 252.94, 0, 0, 0, 0, 0, 0, 9999999, 0, 4985, 0, -1, 0, 10000, 0, 14),
(5, -1, '', '0', 5, 650000, 1, NULL, 6, 3270, 100, 1950.08, 1912.7, 15.4655, 1950.08, 1912.7, 15.4655, 0, 0, 0, 0, 0, 0, 9999999, 550, 3834, 0, -1, 0, 10000, 0, 15),
(6, -1, '', '0', 7, 5900000, 1, NULL, 29, 390000, 100, 449.663, 2204.34, 12.1032, 449.663, 2204.34, 12.1032, 0, 0, 0, 0, 0, 0, 9999999, 390000, 3325, 0, -1, 0, 10000, 0, 13),
(7, -1, '', '0', 8, 9000000, 1, NULL, 28, 4000, 100, 431.576, 1180.2, 12.0006, 431.576, 1180.2, 12.0006, 0, 0, 0, 0, 0, 0, 9999999, 14880, 8275, 0, -1, 0, 10000, 0, 14),
(8, -1, '', '0', 3, 1700000, 1, NULL, 23, 1203620, 100, 2577.56, -2377.62, 22.9376, 2578.64, -2376.92, 22.9376, 0, 0, 0, 0, 0, 0, 9999999, 72070, 3306, 0, -1, 0, 10000, 0, 15),
(9, -1, '', '0', 10, 1600000, 1, NULL, 29, 24830, 100, 128.149, 649.008, 12.7601, 128.149, 649.008, 12.7601, 0, 0, 0, 0, 0, 0, 9999999, 0, 1825, 0, -1, 0, 10000, 0, 13),
(10, -1, '', '0', 9, 2900000, 1, NULL, 28, 28050, 100, 2328.47, -1804.1, 22.454, 2328.47, -1804.1, 2328.47, 0, 0, 0, 0, 0, 0, 9999999, 28050, 4800, 0, -1, 0, 10000, 0, 14),
(11, -1, '', '0', 11, 1600000, 1, NULL, 22, 231380, 100, 203.72, 828.261, 13.3831, 203.72, 828.261, 13.3831, 0, 0, 0, 0, 0, 0, 400000, 55940, 3450, 0, -1, 0, 10000, 0, 15),
(12, -1, '', '0', 11, 1100000, 1, NULL, 29, 100000, 100, 1921.23, 2092.98, 16.1989, 1921.23, 2092.98, 16.1989, 0, 0, 0, 0, 0, 0, 400000, 0, 4900, 0, -1, 0, 10000, 0, 13),
(13, -1, '', '0', 11, 1400000, 1, NULL, 29, 180000, 100, 2260.82, -2106.86, 21.9688, 2260.82, -2106.86, 21.9688, 0, 0, 0, 0, 0, 0, 400000, 180000, 4325, 0, -1, 0, 10000, 0, 14),
(14, -1, '', '0', 11, 1450000, 1, NULL, 18, 827000, 100, -2494.29, 2937.17, 38.1184, -2494.29, 2937.17, 38.1184, 0, 0, 0, 0, 0, 0, 400000, 0, 4525, 0, -1, 0, 10000, 0, 15),
(15, -1, '', '0', 11, 1750000, 1, NULL, 6, 0, 100, -2157.72, 115.416, 26.1534, -2157.72, 115.416, 26.1534, 0, 0, 0, 0, 0, 0, 400000, 0, 4975, 0, -1, 0, 10000, 0, 13),
(16, -1, '', '0', 1, 1780000, 1, NULL, 13, 0, 100, 302.869, 1664.58, 12.4312, 302.869, 1664.58, 12.4312, 0, 0, 0, 0, 0, 0, 9999999, 0, 4550, 0, -1, 0, 10000, 0, 14),
(17, -1, '', '0', 1, 1780000, 1, NULL, 8, 3150, 100, 150.422, 776.258, 12.1544, 150.422, 776.258, 12.1544, 0, 0, 0, 0, 0, 0, 9999999, 0, 6125, 0, -1, 0, 10000, 0, 15),
(18, -1, '', '0', 1, 3500000, 1, NULL, 28, 107921, 100, 1802.36, 2505.24, 15.8658, 1802.36, 2505.24, 15.8658, 0, 0, 0, 0, 0, 0, 9999999, 74800, 3600, 0, -1, 0, 10000, 0, 13),
(19, -1, '', '0', 1, 1800000, 1, NULL, 24, 318256, 100, 2409.15, -2140.52, 22.729, 2409.15, -2140.52, 22.729, 0, 0, 0, 0, 0, 0, 9999999, 0, -675, 0, -1, 0, 10000, 0, 14),
(20, -1, '', '0', 1, 1950000, 1, NULL, 6, 0, 100, 2310.73, -1911.67, 21.9677, 2310.73, -1911.67, 21.9677, 0, 0, 0, 0, 0, 0, 9999999, 0, 4100, 0, -1, 0, 10000, 0, 15),
(21, -1, '', '0', 1, 1750000, 1, NULL, -1, 0, 100, -2386.43, 259.479, 23.932, -2386.43, 259.479, 23.932, 0, 0, 0, 0, 0, 0, 9999999, 0, 3450, 0, -1, 0, 10000, 0, 13),
(22, -1, '', '0', 1, 1750000, 1, NULL, 14, 36450, 100, -2427.95, 2804.76, 37.7512, -2427.95, 2804.76, 37.7512, 0, 0, 0, 0, 0, 0, 9999999, 450, 2775, 0, -1, 0, 10000, 0, 14),
(23, -1, '', '0', 5, 1650000, 1, NULL, 20, 0, 100, -2374.38, 191.45, 22.585, -2374.38, 191.45, 22.585, 0, 0, 0, 0, 0, 0, 9999999, 0, 4985, 0, -1, 0, 10000, 0, 15),
(24, -1, '', '0', 5, 1300000, 1, NULL, 13, 3300, 100, 2310.72, -1926.24, 21.9677, 2310.72, -1926.24, 21.9677, 0, 0, 0, 0, 0, 0, 9999999, 0, 4720, 0, -1, 0, 10000, 0, 13),
(25, -1, '', '0', 5, 1050000, 1, NULL, 29, 0, 100, -231.392, 942.632, 12.4891, -231.244, 943.897, 12.4891, 0, 0, 0, 0, 0, 0, 9999999, 0, 4984, 0, -1, 0, 10000, 0, 14),
(26, -1, '', '0', 5, 1800000, 1, NULL, 4, 0, 100, -2521.3, 2937.35, 38.1184, -2521.3, 2937.35, 38.1184, 0, 0, 0, 0, 0, 0, 9999999, 0, 4345, 0, -1, 0, 10000, 0, 15),
(27, -1, '', '0', 12, 1500000, 1, NULL, 6, 0, 100, 2349.98, -2138.32, 22.5854, 2349.98, -2138.32, 22.5854, 0, 0, 0, 0, 0, 0, 400000, 0, 5000, 0, -1, 0, 10000, 0, 13),
(28, -1, '', '0', 12, 10000000, 1, NULL, 7, 0, 100, 207.615, 829.745, 13.3831, 207.615, 829.745, 13.3831, 0, 0, 0, 0, 0, 0, 400000, 0, 4324, 0, -1, 0, 10000, 0, 14),
(29, -1, '', '0', 12, 10000000, 1, NULL, 24, 0, 100, 1857.08, 2270.32, 15.5781, 1859.24, 2270.27, 15.274, 0, 0, 0, 0, 0, 0, 400000, 0, 3500, 0, -1, 0, 10000, 0, 15),
(30, -1, '', '0', 12, 10000000, 1, NULL, 3, 0, 100, 2261.1, -2100.62, 21.9688, 2261.1, -2100.62, 21.9688, 0, 0, 0, 0, 0, 0, 400000, 0, 5300, 0, -1, 0, 10000, 0, 13),
(31, -1, '', '0', 1, 2500000, 1, NULL, 3, 0, 100, -197.54, -1376.05, 41.75, -197.54, -1376.05, 41.75, 0, 0, 0, 0, 0, 0, 750000, 0, 4875, 0, -1, 1500, 10000, 0, 15),
(32, -1, '', '0', 5, 2500000, 1, NULL, 12, 0, 100, -321.604, -1827.87, 51.3125, -318.849, -1824.83, 51.3125, 0, 0, 0, 0, 0, 0, 150000, 0, -15, 0, -1, 1500, 10000, 0, 15),
(33, -1, '', '0', 14, 4000000, 1, NULL, 28, 0, 5000, 2219.08, -1960.96, 18.8197, 2219.08, -1960.96, 18.8197, 0, 0, 0, 0, 0, 0, 250000, 0, -33650, 0, -1, 1000, 10000, 0, 15),
(34, -1, '', '0', 14, 4000000, 1, NULL, 28, 537382, 5000, -425.717, 680.484, 12.1529, -425.717, 680.484, 12.1529, 0, 0, 0, 0, 0, 0, 250000, 252970, -39425, 0, -1, 2500, 10000, 0, 15),
(35, -1, '', '0', 13, 8500000, 1, NULL, 29, 540000, 10000, 2197.23, -2279.68, 22.9958, 2197.23, -2279.68, 22.9958, 0, 0, 0, 0, 0, 0, 750000, 0, -8350, 0, -1, 1500, 10000, 0, 15),
(36, -1, '', '0', 1, 1000, NULL, NULL, NULL, NULL, NULL, 1857.39, 2251.25, 15.558, 1858.94, 2251.21, 15.2818, NULL, NULL, NULL, NULL, NULL, NULL, 1000, NULL, NULL, NULL, NULL, NULL, 0, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблиці `fractions`
--

CREATE TABLE `fractions` (
  `id` int(11) NOT NULL,
  `skin` int(3) NOT NULL,
  `name` varchar(24) NOT NULL,
  `x` int(5) NOT NULL,
  `y` int(5) NOT NULL,
  `z` int(5) NOT NULL,
  `a` int(5) NOT NULL,
  `bank` int(9) NOT NULL DEFAULT 0,
  `vw` int(3) NOT NULL DEFAULT 0,
  `type` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп даних таблиці `fractions`
--

INSERT INTO `fractions` (`id`, `skin`, `name`, `x`, `y`, `z`, `a`, `bank`, `vw`, `type`) VALUES
(1, 114, 'russian опг', 1866, 2268, 15, 237, 0, 0, 0),
(2, 116, 'american опг', 1866, 2268, 15, 237, 0, 0, 1);

--
-- Індекси збережених таблиць
--

--
-- Індекси таблиці `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `buisness`
--
ALTER TABLE `buisness`
  ADD PRIMARY KEY (`buisnes_id`);

--
-- Індекси таблиці `fractions`
--
ALTER TABLE `fractions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для збережених таблиць
--

--
-- AUTO_INCREMENT для таблиці `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT для таблиці `buisness`
--
ALTER TABLE `buisness`
  MODIFY `buisnes_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT для таблиці `fractions`
--
ALTER TABLE `fractions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
